import React from "react";
import AnimatedCat from "../AnimatedCat/AnimatedCat";
import cl from "./_Timer.module.scss";

const Timer = ({ transfer, setTransferData, reference, endTimer}) => {
  const [timer, setTimer] = React.useState('00:00');
  const intervalTime = React.useRef(null)
  const seconds = React.useRef(1)
  const minutes = React.useRef(0);
  React.useEffect(()=>{

		if(reference.current === 1){
			seconds.current = 1
			minutes.current = 0
			intervalTime.current = setInterval(() => {
        if (seconds.current === 60) {
          seconds.current = 0;
          minutes.current++;
        }
        if (seconds.current > 9 && minutes.current > 9)
          setTimer(`${minutes.current}:${seconds.current}`);
        if (seconds.current > 9 && minutes.current < 10)
          setTimer(`0${minutes.current}:${seconds.current}`);
        if (seconds.current < 10 && minutes.current > 9)
          setTimer(`${minutes.current}:0${seconds.current}`);
        if (seconds.current < 10 && minutes.current < 10)
          setTimer(`0${minutes.current}:0${seconds.current}`);
        seconds.current++;
      }, 1000);
		}
  }, [reference.current])

	React.useEffect(() => {
    if (!transfer.timerIsActive && reference.current === 0) {
      setTimer('00:00');
      clearInterval(intervalTime.current);
      return;
    }
  }, [transfer.timerIsActive]);

  React.useEffect(()=>{
		return () => {
			if(endTimer.current){
        setTransferData((prevData) => {
          return {
            ...prevData,
            time: { minutes: minutes.current, seconds: seconds.current },
          };
        });
      }
		}
  }, [])

  
  return (
    <div className={cl.TimerBlock}>
      <AnimatedCat
        transfer={transfer}
        width={220}
        height={135}
        style={{ position: 'absolute', top: '-40px' }}
				stopAnimate = {reference}
      />
      <span className={cl.TimerSpan}>{timer}</span>
    </div>
  );
};
 
export default Timer;