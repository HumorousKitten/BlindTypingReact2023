import React from "react";
import { useNavigate } from "react-router-dom";
import { HandySvg } from 'handy-svg';
import cl from "./_Header.module.scss";
import iconBlindTyping from '../../img/icons/logo.svg';
import avatarIcon from '../../img/icons/avatar.svg';
import documentIcon from '../../img/icons/list.svg';

const Header = (props) => {
		const [userName, setUserName] = React.useState("");
		const {server, token} = props
		const navigate = useNavigate()

		React.useEffect(()=>{
			(async () => {
        const {login} = await server.getUserData(token);
        setUserName(login);
      })();
		}, [])

		function toAccountPage(){
			navigate('/account')
		}

    function toMainPage(){
      navigate("/")
    }

    function toAboutPage(){
      navigate("/about")
    }

    return (
      <header className={cl.Header}>
        <div className={cl.TitleBlock} onClick={toMainPage}>
          <HandySvg src={iconBlindTyping} width='18' height='18'/>
          <span className={cl.Span}>BlindTyping</span>
        </div>

        <div className={cl.AvatarBlock}>
          <HandySvg src={avatarIcon} width='22' height='22' />
          <span className={cl.Span} onClick={toAccountPage}>{userName}</span>
          <HandySvg src={documentIcon} width='18' height='18' onClick={toAboutPage}/>
        </div>
      </header>
    );
};

export default Header;
