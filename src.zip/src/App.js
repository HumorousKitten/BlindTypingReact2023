import React from 'react';
import { Navigate} from 'react-router-dom';
import {BrowserRouter as Router, Routes, Route,} from 'react-router-dom';
import Server  from './server';
import SimulatorPage from './Pages/BlindSimulator/SimulatorPade';
import LevelsPage from './Pages/LevelsPage/LevelsPage';
import About from './Pages/About/About';
import RegistrationPage from './Pages/Registration/Registration';
import AutorizationPage from './Pages/autorization/AutorizationPage';
import AccountInfo from './Pages/AccountInfo/AccountInfo';
import './mainStyles.scss';

function App() {
  const server = new Server();
  
  const [dataOfUser, setDataOfUser] = React.useState(() => {
    return {
      token: server.readCookie('token')
    }
  });


  const [transferData, setTransferData] = React.useState({
    levelId: 0,
    subLevel: 1,
    startTyping: null,
    endTyping: false,
    timerIsActive: false,
    time: {
      minutes: 0,
      seconds: 0
    }
  });

  return (
    <div className='App'>
      <Router>
        <Routes>
          <Route
            exact
            path='/autorization'
            element={
              <AutorizationPage
                server={server}
                setDataOfUser={setDataOfUser}
                transfer={transferData}
                setTransferData={setTransferData}
              />
            }
          />
          <Route
            exact
            path='/'
            element={
              dataOfUser.token ? (
                <SimulatorPage
                  server={server}
                  transfer={transferData}
                  setTransferData={setTransferData}
                  token={dataOfUser.token}
                />
              ) : (
                <Navigate to='/autorization' />
              )
            }
          />
          <Route
            exact
            path='/levels'
            element={
              dataOfUser.token ? (
                <LevelsPage
                  server={server}
                  transfer={setTransferData}
                  token={dataOfUser.token}
                />
              ) : (
                <Navigate to='/autorization' />
              )
            }
          />
          <Route
            exact
            path='/about'
            element={
              dataOfUser.token ? (
                <About server={server} token={dataOfUser.token} />
              ) : (
                <Navigate to='/autorization' />
              )
            }
          />
          <Route
            exact
            path='/registration'
            element={
              <RegistrationPage
                server={server}
                transfer={transferData}
                setTransferData={setTransferData}
              />
            }
          />
          <Route
            exact
            path='/account'
            element={
              dataOfUser.token ? (
                <AccountInfo server={server} token={dataOfUser.token} />
              ) : (
                <Navigate to='/autorization' />
              )
            }
          />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
