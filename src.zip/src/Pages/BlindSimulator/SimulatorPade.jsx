import React from "react";
import Timer from "../../Components/Timer/Timer";
import SimulatorBlock from "../../Components/SimulatorBlock/SimulatorBlock";
import Header from "../../Components/Header/Header";
const SimulatorPage = ({ server, transfer, setTransferData, token}) => {
  const startingTimer = React.useRef(null);
  const endTimer = React.useRef(false);

  return (
    <>
      <Header server={server} token={token} />
      {!transfer.endTyping && (
        <Timer
          transfer={transfer}
          setTransferData={setTransferData}
          reference={startingTimer}
          endTimer={endTimer}
        />
      )}
      <SimulatorBlock
        server={server}
        transfer={transfer}
        setTransferData={setTransferData}
        token={token}
        startTimer={startingTimer}
        endTimer={endTimer}
      />
    </>
  );
};
 
export default SimulatorPage;